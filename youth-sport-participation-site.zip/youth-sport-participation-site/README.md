# More Than a Game — Youth Sport Participation

A responsive, accessible, static website for a student research project on barriers to young people's participation in sport, linked to UN Sustainable Development Goal 3: Good Health and Well-being.

## What's included
- `index.html` — page structure and research content
- `styles.css` — responsive styling for mobile, tablet and desktop
- `script.js` — accessible mobile navigation
- `assets/` — optional place for your own images or other assets

## Run locally
Open `index.html` in a browser. No build tools or dependencies are required. Google Fonts are loaded from the web; the site will still work if they are unavailable.

## Publish with GitHub Pages
1. Create a new repository on GitHub.
2. Upload `index.html`, `styles.css`, `script.js`, `README.md` and the `assets` folder.
3. Open the repository's **Settings → Pages**.
4. Under the build/deployment section, choose **Deploy from a branch**.
5. Select your main branch and `/ (root)`, then save.
6. Wait for the Pages URL to appear in the Pages settings.

## Before submitting
- Check every statistic against the original report linked on the page.
- Add your name/class only if your teacher expects it.
- Add your own survey or interview findings when you have collected them.
- Check links and proofread the wording.
- The percentages come from different surveys and sample groups, so they should not be treated as directly comparable.
- The "current action" section provides examples and links to official organisations. Check official pages for up-to-date programmes and local eligibility.

## Accessibility and responsive features
- Responsive layouts for phones, tablets and desktop screens
- Semantic page sections and a skip link
- Keyboard-operable mobile menu with Escape support
- Visible keyboard focus on the interactive checklist
- Reduced-motion preference support
- External links use `rel="noopener"`
